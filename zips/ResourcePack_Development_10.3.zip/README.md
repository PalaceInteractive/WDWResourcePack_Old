MCMagic Resource Pack

To use this with your client:

1. Click the clone or download button. 
2. Download as zip.
3. Place zip in your resourcepack folder.

******************************************************************************************
This is a version of the RP that is still being developed!

Things may and will be broken, please do not report bugs/issues when using this pack.

The Master branch is the only branch we provide support for.

Credit to @William_Malo for allowing us to use resources from WillPack
******************************************************************************************
